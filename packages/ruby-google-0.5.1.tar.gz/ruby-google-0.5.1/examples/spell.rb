#!/usr/bin/env ruby
#
# $Id: spell.rb,v 1.4 2002/04/15 02:15:45 ianmacd Exp $

require 'google'

KEY = File.open("#{ENV['HOME']}/.google_key") {|kf| kf.readline.chomp}

query = ARGV.shift || "tis izn't ho yoou spel wordz!"
google = Google::Search.new(KEY)
correction = google.spell(query)
puts correction
