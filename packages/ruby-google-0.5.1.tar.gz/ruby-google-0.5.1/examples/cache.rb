#!/usr/bin/env ruby
#
# $Id: cache.rb,v 1.4 2002/04/15 02:15:45 ianmacd Exp $

require 'google'

KEY = File.open("#{ENV['HOME']}/.google_key") {|kf| kf.readline.chomp}

site = ARGV.shift || 'www.caliban.org'
google = Google::Search.new(KEY)
page = google.cache(site)
puts page
